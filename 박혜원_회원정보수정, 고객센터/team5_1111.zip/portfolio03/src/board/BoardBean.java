package board;

import java.sql.Timestamp;

public class BoardBean {
	private String b_name;
	private String b_name_hidden;
	private int b_id;
	private String b_title;
	private String b_content;
	private String b_hashtag;
	private int b_suggest;
	private Timestamp b_date;
	private int b_hit;
	
	public static int pageSize=3;
	public static int pageCount=1;
	public static int pageNum=1;
	
	public static String pageNum(int limit) {
		String str="";
		int temp=(pageNum - 1) % limit;
		int startPage = pageNum - temp;
		
		if ((startPage - limit) > 0) {
			str = "<a href='Board_list.jsp?pageNum="+(startPage-1)+"'>[����]</a>&nbsp;&nbsp;";
		}
		
		for (int i = startPage; i < (startPage+limit); i++) {
			if (i == pageNum) {
				str += "["+i+"]&nbsp;&nbsp;";
			}else {
				str += "<a href='Board_list.jsp?pageNum="+i+"'>["+i+"]</a>&nbsp;&nbsp;";
			}
			if (i >= pageCount) {
				break;
			}
		}
		
		if ((startPage + limit) <= pageCount) {
			str += "<a href='Board_list.jsp?pageNum="+(startPage+limit)+"'>[����]</a>&nbsp;&nbsp;";
		}
		return str;
	}
	
	
	public int getB_hit() {
		return b_hit;
	}
	public void setB_hit(int b_hit) {
		this.b_hit = b_hit;
	}
	public Timestamp getB_date() {
		return b_date;
	}
	public void setB_date(Timestamp b_date) {
		this.b_date = b_date;
	}
	public void setB_id(int b_id) {
		this.b_id = b_id;
	}
	public String getB_name() {
		return b_name;
	}
	public void setB_name(String b_name) {
		this.b_name = b_name;
	}
	public String getB_name_hidden() {
		return b_name_hidden;
	}
	public void setB_name_hidden(String b_name_hidden) {
		this.b_name_hidden = b_name_hidden;
	}
	public int getB_id() {
		return b_id;
	}
	public void setB_ID(int b_id) {
		this.b_id = b_id;
	}
	public String getB_title() {
		return b_title;
	}
	public void setB_title(String b_title) {
		this.b_title = b_title;
	}
	public String getB_content() {
		return b_content;
	}
	public void setB_content(String b_content) {
		this.b_content = b_content;
	}
	public String getB_hashtag() {
		return b_hashtag;
	}
	public void setB_hashtag(String b_hashtag) {
		this.b_hashtag = b_hashtag;
	}
	public int getB_suggest() {
		return b_suggest;
	}
	public void setB_suggest(int b_suggest) {
		this.b_suggest = b_suggest;
	}

}
