package manager;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import customer.CustomerBean;
import customer.CustomerDBBean;
import myUtil.HanConv;

public class ManagerDBBean {
	private static ManagerDBBean instance = new ManagerDBBean();
	
	public static ManagerDBBean getInstance() {
		return instance;
	}
	
	public Connection getConnection() throws Exception {
		Connection conn=null;
		String url="jdbc:oracle:thin:@localhost:1521:xe";	
		String user="stock";
		String password="1234";
		
		Class.forName("oracle.jdbc.driver.OracleDriver");
		conn=DriverManager.getConnection(url, user, password);
		return conn;
	}
	
	public boolean checkManager(String id) {
		Connection conn=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		String sql="select man_id from manager where man_id=?";
		int re=-1;
		
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, id);
			rs=pstmt.executeQuery();
			if(rs.next()) {
				return true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			try {
				if(conn!=null) conn.close();
				if(pstmt!=null)pstmt.close();
				if(rs!=null)rs.close();
			} catch (Exception e2) {
				// TODO: handle exception
				e2.printStackTrace();
			}
		}
		return false;
	}
	
	public int insertManager(String cus_id,String id) throws Exception{
		if(!checkManager(id)) {
			System.out.println("�����ڰ� �ƴմϴ�.");
			return -1;
		}
		CustomerDBBean customer=CustomerDBBean.getInstance();
		CustomerBean cus=customer.getCustomer(cus_id);
		Connection conn=null;
		PreparedStatement pstmt=null;
		String sql="insert into manager (man_id,man_pwd,man_name) values(?,?,?)";
		int re=-1;
		
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, cus.getCus_id());
			pstmt.setString(2, cus.getCus_pwd());
			pstmt.setString(3, cus.getCus_nickname());
			re = pstmt.executeUpdate();
			System.out.println("�߰� ����");
		} catch (Exception e) {
			System.out.println("�߰� ����");
			e.printStackTrace();
		}finally {
			try {
				if(conn!=null) conn.close();
				if(pstmt!=null)pstmt.close();
			} catch (Exception e2) {
				// TODO: handle exception
				e2.printStackTrace();
			}
		}
		
		return re;
	}
	
	public int deleteManager(String man,String id) {
		if(!checkManager(id)) {
			System.out.println("�����ڰ� �ƴմϴ�.");
			return -1;
		}
		if(man.equals("admin")) {
			System.out.println("������ �Ұ����մϴ�");
			return -1; 
		}
		Connection conn=null;
		PreparedStatement pstmt=null;
		String sql="delete from manager where man_id=?";
		int re=-1;
		
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, man);
			re = pstmt.executeUpdate();
			System.out.println("���� ����");
		} catch (Exception e) {
			System.out.println("���� ����");
			e.printStackTrace();
		}finally {
			try {
				if(conn!=null) conn.close();
				if(pstmt!=null)pstmt.close();
			} catch (Exception e2) {
				// TODO: handle exception
				e2.printStackTrace();
			}
		}
		
		return re;
	}
	
	public int editManager(ManagerBean man, String id) {
		if(!checkManager(id)) {
			System.out.println("�����ڰ� �ƴմϴ�.");
			return -1;
		}
		if(!man.getMan_id().equals(id)) {
			System.out.println("����ڰ� �ƴϸ� ������ �Ұ����մϴ�");
			return -1; 
		}
		Connection conn=null;
		PreparedStatement pstmt=null;
		String sql="update manager set man_pwd=?,man_name=? where man_id=?";
		int re=-1;
		
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, man.getMan_pwd());
			pstmt.setString(2, man.getMan_name());
			pstmt.setString(3, man.getMan_id());
			re = pstmt.executeUpdate();
			System.out.println("���� ����");
		} catch (Exception e) {
			System.out.println("���� ����");
			e.printStackTrace();
		}finally {
			try {
				if(conn!=null) conn.close();
				if(pstmt!=null)pstmt.close();
			} catch (Exception e2) {
				// TODO: handle exception
				e2.printStackTrace();
			}
		}
		
		return re;
	}
}
