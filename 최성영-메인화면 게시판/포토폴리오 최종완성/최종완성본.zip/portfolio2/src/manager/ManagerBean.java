package manager;

public class ManagerBean {
	private String man_id;
	private String man_pwd;
	private String man_name;
	private int man_level;
	
	public int getMan_level() {
		return man_level;
	}

	public void setMan_level(int man_level) {
		this.man_level = man_level;
	}

	public ManagerBean() {
		// TODO Auto-generated constructor stub
	}
	
	public ManagerBean(String man_id, String man_pwd, String man_name, int man_level) {
		super();
		this.man_id = man_id;
		this.man_pwd = man_pwd;
		this.man_name = man_name;
		this.man_level = man_level;
	}
	public String getMan_id() {
		return man_id;
	}
	public void setMan_id(String man_id) {
		this.man_id = man_id;
	}
	public String getMan_pwd() {
		return man_pwd;
	}
	public void setMan_pwd(String man_pwd) {
		this.man_pwd = man_pwd;
	}
	public String getMan_name() {
		return man_name;
	}
	public void setMan_name(String man_name) {
		this.man_name = man_name;
	}
	
}
