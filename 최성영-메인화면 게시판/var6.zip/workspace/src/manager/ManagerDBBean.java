package manager;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import customer.CustomerBean;
import customer.CustomerDBBean;
import myUtil.HanConv;

public class ManagerDBBean {
	private static ManagerDBBean instance = new ManagerDBBean();
	
	public static ManagerDBBean getInstance() {
		return instance;
	}
	
	public Connection getConnection() throws Exception {
		Connection conn=null;
		String url="jdbc:oracle:thin:@localhost:1521:xe";	
		String user="stock";
		String password="1234";
		
		Class.forName("oracle.jdbc.driver.OracleDriver");
		conn=DriverManager.getConnection(url, user, password);
		return conn;
	}
	
	public boolean checkManager(String id) {
		Connection conn=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		String sql="select man_id from manager where man_id=?";
		int re=-1;
		
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, id);
			rs=pstmt.executeQuery();
			if(rs.next()) {
				return true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			try {
				if(conn!=null) conn.close();
				if(pstmt!=null)pstmt.close();
				if(rs!=null)rs.close();
			} catch (Exception e2) {
				// TODO: handle exception
				e2.printStackTrace();
			}
		}
		return false;
	}
	
		
	public int deleteManager(String man,String id) {
		if(!checkManager(id)) {
			System.out.println("�����ڰ� �ƴմϴ�.");
			return -1;
		}
		if(man.equals("admin")) {
			System.out.println("������ �Ұ����մϴ�");
			return -1; 
		}
		Connection conn=null;
		PreparedStatement pstmt=null;
		String sql="delete from manager where man_id=?";
		int re=-1;
		
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, man);
			re = pstmt.executeUpdate();
			System.out.println("���� ����");
		} catch (Exception e) {
			System.out.println("���� ����");
			e.printStackTrace();
		}finally {
			try {
				if(conn!=null) conn.close();
				if(pstmt!=null)pstmt.close();
			} catch (Exception e2) {
				// TODO: handle exception
				e2.printStackTrace();
			}
		}
		
		return re;
	}
	
	public int editManager(ManagerBean man, String id) {
		if(!checkManager(id)) {
			System.out.println("�����ڰ� �ƴմϴ�.");
			return -1;
		}
		if(!man.getMan_id().equals(id)) {
			System.out.println("����ڰ� �ƴϸ� ������ �Ұ����մϴ�");
			return -1; 
		}
		Connection conn=null;
		PreparedStatement pstmt=null;
		String sql="update manager set man_pwd=?,man_name=? where man_id=?";
		int re=-1;
		
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, man.getMan_pwd());
			pstmt.setString(2, man.getMan_name());
			pstmt.setString(3, man.getMan_id());
			re = pstmt.executeUpdate();
			System.out.println("���� ����");
		} catch (Exception e) {
			System.out.println("���� ����");
			e.printStackTrace();
		}finally {
			try {
				if(conn!=null) conn.close();
				if(pstmt!=null)pstmt.close();
			} catch (Exception e2) {
				// TODO: handle exception
				e2.printStackTrace();
			}
		}
		
		return re;
	}
	public ArrayList<ManagerBean> allManager() {
		ArrayList<ManagerBean> all=new ArrayList<ManagerBean>();
		Connection conn=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		String sql="select * from manager order by man_level";
		try{
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			rs=pstmt.executeQuery();
			while(rs.next()) {
				ManagerBean manager=new ManagerBean();
				manager.setMan_id(rs.getString("man_id"));
				manager.setMan_name(rs.getString("man_name"));
				manager.setMan_level(rs.getInt("man_level"));
				all.add(manager);
			}
		}catch (Exception e) {
			e.printStackTrace();
		}finally {
			try {
				if(pstmt != null) pstmt.close();
				if(conn != null) conn.close();				
				if(rs!= null) rs.close();				
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return all;
	}
	public ManagerBean getManager(String id) {
		ManagerBean man=new ManagerBean();
		Connection conn=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		String sql="select * from manager where man_id=?";
		
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, id);
			rs=pstmt.executeQuery();
			if(rs.next()) {
				String man_id=rs.getString("man_id");
				String man_pwd=rs.getString("man_pwd");
				String man_name=rs.getString("man_name");
				int man_level=rs.getInt("man_level");
				man=new ManagerBean(man_id, man_pwd, man_name,man_level);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			try {
				if(conn!=null) conn.close();
				if(pstmt!=null)pstmt.close();
				if(rs!=null)rs.close();
			} catch (Exception e2) {
				// TODO: handle exception
				e2.printStackTrace();
			}
		}
		return man;
	}
	
	public int insertManager(String cus_id,String id) throws Exception{
		if(!checkManager(id)) {
			System.out.println("�����ڰ� �ƴմϴ�.");
			
			return -1;
		}
		ManagerBean ma=getManager(id);
		CustomerDBBean customer=CustomerDBBean.getInstance();
		CustomerBean cus=customer.getCustomer(cus_id);
		Connection conn=null;
		PreparedStatement pstmt=null;
		String sql="insert into manager (man_id,man_pwd,man_name,man_level) values(?,?,?,?)";
		int re=-1;
		
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, cus.getCus_id());
			pstmt.setString(2, cus.getCus_pwd());
			pstmt.setString(3, cus.getCus_nickname());
			pstmt.setInt(4,ma.getMan_level()+1);
			re = pstmt.executeUpdate();
			System.out.println("�߰� ����");
		} catch (Exception e) {
			System.out.println("�߰� ����");
			e.printStackTrace();
		}finally {
			try {
				if(conn!=null) conn.close();
				if(pstmt!=null)pstmt.close();
			} catch (Exception e2) {
				// TODO: handle exception
				e2.printStackTrace();
			}
		}
		
		return re;
	}
	
}
