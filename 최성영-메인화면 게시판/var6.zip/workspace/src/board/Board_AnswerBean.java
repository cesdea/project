package board;

public class Board_AnswerBean {
	private int b_a_id;
	private int b_a_ref;
	private String b_a_name;
	private String b_a_content;
	private String b_a_hidden;
	private int b_a_level;
	private String b_a_name_hidden;
	
	public static int b_a_pageSize=4;
	public static int b_a_pageCount=1;
	public static int b_a_pageNum=1;
	
	public static String pageNum(int limit,int b_id) {
		String str="";
		int temp=(b_a_pageNum - 1) % limit;
		int startPage = b_a_pageNum - temp;
		
		if ((startPage - limit) > 0) {
			str = "<a href='Board_show.jsp?pageNum="+(startPage-1)+"&b_id="+b_id+"'>[����]</a>&nbsp;&nbsp;";
		}
		
		for (int i = startPage; i < (startPage+limit); i++) {
			if (i == b_a_pageNum) {
				str += "["+i+"]&nbsp;&nbsp;";
			}else {
				str += "<a href='Board_show.jsp?pageNum="+i+"&b_id="+b_id+"'>["+i+"]</a>&nbsp;&nbsp;";
			}
			if (i >= b_a_pageCount) {
				break;
			}
		}
		
		if ((startPage + limit) <= b_a_pageCount) {
			str += "<a href='Board_show.jsp?pageNum="+(startPage+limit)+"&b_id="+b_id+"'>[����]</a>&nbsp;&nbsp;";
		}
		return str;
	}
	
	public String getB_a_name_hidden() {
		return b_a_name_hidden;
	}
	public void setB_a_name_hidden(String b_a_name_hidden) {
		this.b_a_name_hidden = b_a_name_hidden;
	}
	public int getB_a_level() {
		return b_a_level;
	}
	public void setB_a_level(int b_a_level) {
		this.b_a_level = b_a_level;
	}
	public String getB_a_hidden() {
		return b_a_hidden;
	}
	public void setB_a_hidden(String b_a_hidden) {
		this.b_a_hidden = b_a_hidden;
	}
	public int getB_a_id() {
		return b_a_id;
	}
	public void setB_a_id(int b_a_id) {
		this.b_a_id = b_a_id;
	}
	public int getB_a_ref() {
		return b_a_ref;
	}
	public void setB_a_ref(int b_a_ref) {
		this.b_a_ref = b_a_ref;
	}
	public String getB_a_name() {
		return b_a_name;
	}
	public void setB_a_name(String b_a_name) {
		this.b_a_name = b_a_name;
	}
	public String getB_a_content() {
		return b_a_content;
	}
	public void setB_a_content(String b_a_content) {
		this.b_a_content = b_a_content;
	}
	
}
