package service;

public class ServiceAnswerBean {
	private int s_a_id;
	private int s_a_ref;
	private String s_a_name;
	private String s_a_content;
	
	public int getS_a_id() {
		return s_a_id;
	}
	public void setS_a_id(int s_a_id) {
		this.s_a_id = s_a_id;
	}
	public int getS_a_ref() {
		return s_a_ref;
	}
	public void setS_a_ref(int s_a_ref) {
		this.s_a_ref = s_a_ref;
	}
	public String getS_a_name() {
		return s_a_name;
	}
	public void setS_a_name(String s_a_name) {
		this.s_a_name = s_a_name;
	}
	public String getS_a_content() {
		return s_a_content;
	}
	public void setS_a_content(String s_a_content) {
		this.s_a_content = s_a_content;
	}
}
